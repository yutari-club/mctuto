# CustomBlocks
Custom blocks for Minecraft courses



> Open this page at [https://fountainstudios.github.io/customblocks/](https://fountainstudios.github.io/customblocks/)

## Use as Extension

This repository can be added as an **extension** in MakeCode.

* open [https://minecraft.makecode.com/](https://minecraft.makecode.com/)
* click on **New Project**
* click on **Extensions** under the gearwheel menu
* search for **https://github.com/fountainstudios/customblocks** and import

## Edit this project ![Build status badge](https://github.com/fountainstudios/customblocks/workflows/MakeCode/badge.svg)

To edit this repository in MakeCode.

* open [https://minecraft.makecode.com/](https://minecraft.makecode.com/)
* click on **Import** then click on **Import URL**
* paste **https://github.com/fountainstudios/customblocks** and click import

## Blocks preview

This image shows the blocks code from the last commit in master.
This image may take a few minutes to refresh.

![A rendered view of the blocks](https://github.com/fountainstudios/customblocks/raw/master/.github/makecode/blocks.png)

#### Metadata (used for search, rendering)

* for PXT/minecraft
<script src="https://makecode.com/gh-pages-embed.js"></script><script>makeCodeRender("{{ site.makecode.home_url }}", "{{ site.github.owner_name }}/{{ site.github.repository_name }}");</script>
