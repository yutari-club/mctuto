# Activity 4 – A Wild Ride.

### @explicitHints true
### @hideIteration true 
### @flyoutOnly 0

```python
player.say
```

## Step 1
In this Activity, you need to go to the different locations that the AI found and close them down. 
You need to use banners to signify that the areas are closed and nobody can access them. **No coding is required for this Activity.** 
