# Activity 1 – Flying high.

### @explicitHints true
### @hideIteration true 
### @flyoutOnly 0

```python
player.say
```
## Step 1
Data needs to be gathered about the forest, by taking pictures.
Whilst flying over the forest use your camera, that's in your hotbar, to take pictures of the terrain. 
**No coding is required for this activity.**

