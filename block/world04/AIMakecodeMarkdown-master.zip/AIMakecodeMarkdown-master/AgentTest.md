### @codeStart players set @s makecode 0
### @codeStop players set @s makecode 1

```template
// onStart block only
```
### @flyoutOnly 1
### @hideIteration true 
### @explicitHints 1
# 5. Eliminate All Hazards.
## Introduction step @unplugged
