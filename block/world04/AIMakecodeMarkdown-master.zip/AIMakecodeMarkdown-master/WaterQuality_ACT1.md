# Activity 1 – Widespread illness.

### @explicitHints true
### @hideIteration true 
### @flyoutOnly 0

```python
player.say
```

## Step 1
The people in the village have been getting sick, all with the same symptoms. We suspect that it is the water that everybody is 
drinking. It must be contaminated in some way. We want to use AI to find the locations where the pollutants are coming from. 
However, before we can do this we need to collect water samples, from the rivers around the village, for a database.
Get into the boat and use the water bottles from the chest, when you are at each of the locations, to a collect water sample. 
**No coding is required for this Activity.**
