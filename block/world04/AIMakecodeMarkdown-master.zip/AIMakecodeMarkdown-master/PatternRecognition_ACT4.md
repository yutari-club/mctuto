# Activity 4 – Who is that ocelot?

### @explicitHints true
### @hideIteration true 
### @flyoutOnly 0

```python
player.say
```

## Step 1
Now that we know the locations of the ocelots we need to find them to see if the AI was correct. Take the map from the chest, on the back of the jeep,
and use it to find the **three** ocelots that we photographed earlier. Try to get close to each ocelots to confirm that they are infact the same animals 
as before. **No coding is required for this Activity. **
