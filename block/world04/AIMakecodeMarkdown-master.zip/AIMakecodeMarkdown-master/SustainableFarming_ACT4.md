# Activity 4 – Green thumb.

### @explicitHints true
### @hideIteration true 
### @flyoutOnly 0

```python
player.say
```

## Step 1
Now that the AI has predicted the best locations to farm, 
go to the corrects plots and tell the farmers to plant there by pressing the button on the gold block.
**No coding is required for this Activity.**