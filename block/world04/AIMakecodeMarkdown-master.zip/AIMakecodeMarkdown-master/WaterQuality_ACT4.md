# Activity 4 – Cleaning up.

### @explicitHints true
### @hideIteration true 
### @flyoutOnly 0

```python
player.say
```

## Step 1
Now that the AI has located the sources where the pollution is coming from, we need to make sure that they are correct. If they are, 
then we need to stop the pollution coming from these locations. 
Get into the boat to go to each of the locations, and place a banner on the gold block to close them off. 
**No coding is required for this Activity.**
