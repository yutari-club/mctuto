# Activity 1 – Into the bush.

### @explicitHints true
### @hideIteration true 
### @flyoutOnly 0

```python
player.say
```

## Step 1
We are in the middle of a savannah studying the movement patterns of ocelots. 
We want to use AI to help us in this endeavor, which would greatly aid the conservation efforts directed towards these animals. 
We first need to make a photographic dataset of the ocelots as each has a unique coat pattern. We will then be able to track each ocelot by comparing 
the data that we have, against the new data comming in from all over the savannah. 
Use the map, from the chest on the back of the jeep, to find the different trap cameras. Then use each camera to photograph an ocelot by 
pressing the button at the back. **No coding is required for this Activity.**