# Activity 1 – Whithering crops.

### @explicitHints true
### @hideIteration true 
### @flyoutOnly 0

```python
player.say
```

## Step 1
We are in a village in a remote area. The people in the village have not been able to get successful yields while farming, 
as they do not know the best locations to farm. 
That is why we are here, using AI and predictive analysis we will be able to locate plots of land that are best 
suited for the crops that they grow. However, before we can do that, we need to gather satellite data of the area. 
Place the satellite beacons on the **gold** blocks around the village. **No coding is required for this Activity.**
