### @explicitHints 1

# Test - V5

## Step 1
Test

```ghost
Input.sensor1()

Datasets.test()

Datasets.setOfdata(function() {})

AI.placeBlock()

AI.mlMappingTerrain(function() {})
```

```package
aicustomblocks=github:fountainstudios/AICustomBlocks
```
