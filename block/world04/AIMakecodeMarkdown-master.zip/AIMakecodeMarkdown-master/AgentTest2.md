### @explicitHints true
### @hideIteration true 

#Testing it out.

## Step 1
Agent moves test V2

```ghost
Test.testMoves()
Test.testLoop(function() {})
```

```package
aicustomblocks=github:fountainstudios/AICustomBlocks
```
