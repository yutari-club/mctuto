### @explicitHints 1

# OCEAN OBSERVATIONS - NICE CORALS

## Step 1
CODE CODE CODE

```template
AI.compare2(0)
```

```ghost
Input.sensor1()
Input.sensor2()
Input.sensor3()
Input.sensor4()


datasets.liveDataset()
datasets.onEvent(datasetType.historical, function() {})

AI.analyze()
AI.onEvent3(function() {})
AI.compare2(0)

Goals.reach1()
Goals.reach2()
Goals.reach3()
Goals.reach4()
```

```package
aicustomblocks=github:fountainstudios/AICustomBlocks
```
