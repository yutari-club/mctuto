# Activity 1 – The great blue.

### @explicitHints true
### @hideIteration true 

```python
player.say
```

## Step 1
Hey! I am glad you are here. We are at sea, right next to a coral reef. The reason for that is to observe and research the impact of climate change on the corals. 
To do that we need to place some sensors in the reef, which means we need somebody to dive down into the water. 
Take the sensors from the chest on the deck of the boat. Then dive into the water and place the sensors in the **four** spots on the ocean floor marked 
with a **red banner** above the surface of the water, and with **lamps** on the sea floor. 
Once you have placed all four sensors activity 1 is complete and you can get back to the boat. 
**No coding is required in this activity**.
